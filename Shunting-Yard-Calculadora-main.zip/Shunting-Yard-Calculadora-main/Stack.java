public class Stack {
    char dato;
    Stack siguiente;
}
