public class Queue {
    int dato;
    Queue siguiente;
    Queue anterior;    
}
