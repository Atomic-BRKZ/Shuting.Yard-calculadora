# Shunting-Yard-Calculadora
Realizar un programa que lea desde un archivo de texto N expresiones aritméticas,   El programa deberá devolver el resultado correcto de cada expresión
